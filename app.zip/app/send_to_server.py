import requests
import os
from dotenv import load_dotenv

load_dotenv()

SPRING_SERVER = "http://localhost:8080"
JWT_TOKEN = os.getenv("JWT_TOKEN")


def send_restaurant(restaurant: dict) -> tuple:
    url = f"{SPRING_SERVER}/api/restaurants"
    headers = {"Authorization": f"Bearer {JWT_TOKEN}"}
    response = requests.post(url, json=restaurant, headers=headers)
    return response.status_code, response.text

def restaurant_is_exist(place_id: str) -> bool:
    try:
        url = f"{SPRING_SERVER}/api/restaurants/{place_id}"
        headers = {"Authorization": f"Bearer {JWT_TOKEN}"}
        response = requests.get(url, headers=headers)
        return response.ok and response.json()
    except Exception as e:
        return False

def send_reviews(place_id: str, reviews: list) -> tuple:
    url = f"{SPRING_SERVER}/api/restaurants/{place_id}/reviews"
    headers = {"Authorization": f"Bearer {JWT_TOKEN}"}
    response = requests.post(url, json=reviews, headers=headers)
    return response.status_code, response.text

def send_keywords(place_id: str, keywords: list) -> tuple:
    url = f"{SPRING_SERVER}/api/keywords"
    headers = {"Authorization": f"Bearer {JWT_TOKEN}"}
    try:
        payload = {
            "placeId" : place_id,
            "keywords": keywords
        }
        response = requests.post(url, json=payload, headers=headers)
        return response.status_code, response.text
    except requests.RequestException as e:
        return 500, f"요청 실패: {e}"

def send_summary(place_id: str, summary: str) -> tuple:
    url = f"{SPRING_SERVER}/api/restaurants/{place_id}/summary"
    response = requests.post(
    url,
    data=summary.encode("utf-8"),  # optional
    headers={
        "Authorization": f"Bearer {JWT_TOKEN}",
        "Content-Type": "text/plain"
    }
)
def send_category(place_id: str, category: str) -> tuple:
    url = f"{SPRING_SERVER}/api/restaurants/{place_id}/category"
    headers = {
        "Authorization": f"Bearer {JWT_TOKEN}",
        "Content-Type": "text/plain"
    }

    try:
        response = requests.post(url, data=category.encode("utf-8"), headers=headers)
        if response.status_code == 200:
            print(f"✅ 카테고리 전송 성공: {place_id} → {category}")
        else:
            print(f"⚠️ 전송 실패: {response.status_code} - {response.text}")
        return (response.status_code, response.text)
    except requests.exceptions.RequestException as e:
        print(f"❌ 요청 예외 발생: {e}")
        return (500, str(e))

    return response.status_code, response.text