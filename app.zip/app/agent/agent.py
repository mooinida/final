from langchain.agents import initialize_agent, AgentType
from langchain_core.prompts import ChatPromptTemplate
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain_core.tools import Tool

from app.tools.restaurant_save_to_DB_tool import process_and_store_restaurants
from service.review_fetch import get_review_texts

import os
from dotenv import load_dotenv

load_dotenv()
GOOGLE_API_KEY = os.getenv("GOOGLE_API_KEY")

# LLM 초기화 (Gemini)
llm = ChatGoogleGenerativeAI(
    model="models/gemini-1.5-pro",
    google_api_key=GOOGLE_API_KEY
)

# 사용할 툴 등록
tools = [
    process_and_store_restaurants,
    get_review_texts
]

# 에이전트 초기화
agent = initialize_agent(
    tools=tools,
    llm=llm,
    agent_type=AgentType.OPENAI_FUNCTIONS,  # tool 사용 최적화된 타입
    verbose=True,
    handle_parsing_errors=True
)

# 예시 실행 함수
async def run_agent_query(query: str):
    response = await agent.ainvoke({"input": query})
    return response

# 예시 사용:
# import asyncio
# asyncio.run(run_agent_query("수원역 주변 깔끔한 고기집 찾아줘"))
