# ✅ save_document.py
import os
import sys
import pickle
from dotenv import load_dotenv
from langchain.docstore.document import Document
from langchain_google_genai import GoogleGenerativeAIEmbeddings
from langchain_community.vectorstores import FAISS

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
from service.saveRestaurant_pipeline import get_nearby_restaurants_DB, findall_restaurants_DB
from service.review_fetch import get_review_texts

# 1. 환경변수 로드
load_dotenv()
GOOGLE_API_KEY = os.getenv("GOOGLE_API_KEY")
import shutil
import os

# 저장된 벡터스토어 디렉터리 삭제
shutil.rmtree("vectorstores/restaurant_faiss", ignore_errors=True)

# 메타데이터가 저장된 Pickle 파일 삭제
if os.path.exists("vectorstores/restaurant_faiss.pkl"):
    os.remove("vectorstores/restaurant_faiss.pkl")
# 2. 임베딩 모델 초기화
embedding_model = GoogleGenerativeAIEmbeddings(
    model="models/embedding-001",
    google_api_key=GOOGLE_API_KEY
)

# 3. 식당 리스트 조회
coords = {"latitude": 37.5815612, "longitude": 127.0036888}
restaurant_list = findall_restaurants_DB()

# 4. 문서화
docs = []
for r in restaurant_list["restaurants"]:
    summary = r.get("summary", "요약 없음")
    reviews = get_review_texts(r["placeId"])  # 리뷰 가져오기

    review_text = "\n".join([
        review["text"] for review in reviews
        if isinstance(review, dict) and "text" in review
    ])

    keywords = ", ".join([kw["name"] for kw in r.get("keywords", []) if isinstance(kw, dict)]) if isinstance(r.get("keywords"), list) else r.get("keywords", "없음")

    location_name = r.get("location", "지역 정보 없음")

    if summary and summary != "요약 없음":
        text = f"""
        [식당 정보]
        -이름: {r['name']}
        -지역: {location_name} 근처
        -키워드: {keywords}
        -주소: {r['address']}
        -평점: {r.get('rating')} 
        -리뷰수: {r.get('reviewCount')}
        -운영 시간: {r.get('openingHours', '정보 없음')}

        [요약]
        {summary}

        [리뷰]
        {review_text}
        """

        doc = Document(
            page_content=text.strip(),
            metadata={
                "placeId": r["placeId"],
                "name": r["name"],
                "address": r["address"],
                "rating": r.get("rating"),
                "reviewCount": r.get("reviewCount"),
                "location": location_name,
                "keywords": keywords
            }
        )
        docs.append(doc)
# 5. FAISS 저장
if os.path.exists("vectorstores/restaurant_faiss/index.faiss"):
    db = FAISS.load_local("vectorstores/restaurant_faiss", embeddings=embedding_model, allow_dangerous_deserialization=True)
    db.add_documents(docs)
else:
    db = FAISS.from_documents(docs, embedding_model)

db.save_local("vectorstores/restaurant_faiss")
with open("vectorstores/restaurant_faiss.pkl", "wb") as f:
    pickle.dump([doc.metadata for doc in docs], f)

print(f"✅ 저장 완료! 문서 수: {len(docs)}개")