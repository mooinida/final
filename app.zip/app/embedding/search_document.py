import sys

import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
from dotenv import load_dotenv
from langchain.prompts import PromptTemplate
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain_community.vectorstores import FAISS
from langchain.chains import RetrievalQA
from langchain_google_genai import GoogleGenerativeAIEmbeddings
from tools.preprocess_question_tool import preprocess_question

# 환경변수 로드
load_dotenv()
GOOGLE_API_KEY = os.getenv("GOOGLE_API_KEY")

prompt = PromptTemplate(
    input_variables=["context", "question"],
    template="""
당신은 사용자에게 식당을 추천하는 지능적인 챗봇입니다.

아래는 식당에 대한 리뷰, 요약, 위치, 키워드, 평점, 리뷰 수, 운영 시간 등의 정보입니다:
{context}

다음 조건을 고려하여, 사용자 질문에 가장 적절한 식당을 추천해주세요:

1. 질문에 나온 **지역(또는 지하철역)**과 최대한 가까운 식당을 우선 고려합니다.
2. **현재 시간 기준으로 영업 중인 식당**을 우선합니다.
3. 질문과 관련된 **키워드(예: 분위기, 음식 종류, 목적 등)**가 포함된 식당을 우선합니다.
4. **평점이 높고 리뷰 수가 많은 식당**을 선호합니다.
5. 식당 이름과 식당에 대한 **리뷰와 요약**을 읽고, 식당이 어떤 종류의 음식을 하는지 추측하시오.

- 관련된 식당이 있다면, 식당 이름, 주소, 분위기, 추천 이유를 간결하게 알려주세요.
- 관련된 식당이 명확하지 않더라도, 비슷한 지역/분위기/메뉴를 가진 식당이 있다면 추천해도 됩니다.

질문: {question}  
답변:
"""
)
# 🔹 Gemini LLM + 임베딩 모델 초기화
embedding_model = GoogleGenerativeAIEmbeddings(
    model="models/embedding-001",
    google_api_key=GOOGLE_API_KEY
)

llm = ChatGoogleGenerativeAI(
    model="models/gemini-1.5-pro",
    temperature=0,
    google_api_key=GOOGLE_API_KEY
)

# 🔹 FAISS 벡터스토어 로드
vectorstore = FAISS.load_local(
    "vectorstores/restaurant_faiss",
    embeddings=embedding_model,
    allow_dangerous_deserialization=True
)

# 🔹 QA 체인 구성
qa_chain = RetrievalQA.from_chain_type(
    llm=llm,
    retriever=vectorstore.as_retriever(),
    chain_type_kwargs={"prompt": prompt},
     return_source_documents=True

)

# 🔎 사용자 질문 반복 처리
while True:
    user_input = input("🔎 식당에 대해 궁금한 점을 입력하세요 (종료하려면 'exit'): ")
    question = preprocess_question.invoke({"user_input" : user_input})
    if user_input.lower() == "exit":
        break
    answer = qa_chain.invoke(question)
    print("🤖 추천 결과:\n", answer["result"])
    print("🔗 참조된 문서 수:", len(answer["source_documents"]))
