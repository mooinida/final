
import asyncio
import requests
import os
from dotenv import load_dotenv
from langchain_core.tools import tool
import sys
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
from service.saveRestaurant_pipeline import get_nearby_restaurants_DB
load_dotenv()
SPRING_SERVER = "http://localhost:8080"
JWT_TOKEN = os.getenv("JWT_TOKEN")




from tools.restaurant_save_to_DB_tool import process_and_store_restaurants
from service.review_fetch import get_review_texts
from tools.selectRestaurant_tool import recommend_by_keywords, summarize_reviews



if __name__ == "__main__":
    input_text = "동대문역 식당 추천"
    #result = get_review_texts("ChIJjbSKJRlDezURmgw9Dh8cNvM")
    asyncio.run(process_and_store_restaurants.ainvoke({"text": input_text}))
    #summary = summarize_reviews.invoke("ChIJ4agwdYajfDURmWLzFtSBFwM")
    #print(summary)
    #result = recommend_by_keywords(input_text)
    #print(result)
    #reviews = get_review_texts("ChIJXaeN0B1DezURF8xg3HxMFVg")
    #print(reviews)
    #restaurant = get_nearby_restaurants_DB(37.4984321, 127.0263548)
    #print(restaurant)
    
    #print(JWT_TOKEN)