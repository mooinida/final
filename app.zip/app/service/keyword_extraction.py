from service.review_fetch import get_review_texts
from send_to_server import send_keywords, send_summary, send_category
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain_core.prompts import PromptTemplate
import os
from dotenv import load_dotenv

load_dotenv()
GOOGLE_API_KEY = os.getenv("GOOGLE_API_KEY")
llm = ChatGoogleGenerativeAI(model="models/gemini-1.5-pro", google_api_key=GOOGLE_API_KEY)
def process_and_store_keywords(place_id: str, details:dict):
    reviews_data = details.get("reviews", [])
    if not reviews_data:
        print(f"❌ 리뷰 없음: {place_id}")
        return

    reviews = [review.get("text", "") for review in reviews_data if review.get("text")]
    if not reviews:
        print(f"❌ 텍스트 리뷰 없음: {place_id}")
        return

    # 병합
    combined = "\n".join(reviews)  # 어차피 항상 5개만 저장된다면 자르지 않아도 됨

    # 프롬프트 정의 (키워드 + 요약 동시 요청)
    prompt = PromptTemplate.from_template("""
        다음은 한 식당의 리뷰 목록입니다:

        {text}

        위 리뷰들을 기반으로 아래 세 가지 정보를 생성해 주세요:

        1. 이 식당의 특성을 잘 표현하는 **키워드**를 5~8개 추출해 주세요. 쉼표(,)로 구분하고 설명은 생략합니다.
        2. 리뷰 내용을 1~2문장으로 **요약**해 주세요. 긍정적인 점과 부정적인 점 모두 포함해 주세요.
        3. 이 식당에 가장 잘 어울리는 **카테고리**를 골라 주세요. 아래 중 하나로만 작성해 주세요:  
        `중식`, `한식`, `일식`, `양식`, `분식`, `카페`, `패스트푸드`, `기타`

        출력 형식:
        키워드: ...
        요약: ...
        카테고리: ...
        """)

    chain = prompt | llm
    result = chain.invoke({"text": combined})
    content = result.content.strip()

    # 응답 파싱
    try:
        lines = content.splitlines()
        keywords_line = next(line for line in lines if line.startswith("키워드:"))
        summary_line = next(line for line in lines if line.startswith("요약:"))
        category_line = next(line for line in lines if line.startswith("카테고리:"))
        keywords = [kw.strip() for kw in keywords_line.replace("키워드:", "").strip().strip("[]").split(",")]
        summary = summary_line.replace("요약:", "").strip()
        category = category_line.replace("카테고리:", "").strip()
    except Exception as e:
        print(f"❌ 응답 파싱 실패: {e}\n내용: {content}")
        return
    send_category(place_id, category)
    send_keywords(place_id, keywords)
    send_summary(place_id, summary)

