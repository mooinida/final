import requests
import os
from dotenv import load_dotenv

load_dotenv()

SPRING_SERVER = "http://localhost:8080"
JWT_TOKEN = os.getenv("JWT_TOKEN")

def get_review_texts(place_id: str) -> list:
    """
    특정 식당의 리뷰 텍스트 리스트를 Spring 서버에서 가져옵니다.
    """
    url = f"{SPRING_SERVER}/api/restaurants/{place_id}/review-texts"
    headers = {"Authorization": f"Bearer {JWT_TOKEN}"}
    try:
        response = requests.get(url, headers=headers)
        response.raise_for_status()
        return response.json()
    except requests.RequestException as e:
        return [f"리뷰 텍스트 요청 실패: {e}"]
    

def merge_reviews_for_summary(reviews: list[str]) -> str:
    if not reviews:
        return ""
    unique_reviews = list(dict.fromkeys(reviews))
    merged = "\n".join(f"{i+1}. {review}" for i, review in enumerate(unique_reviews))
    return merged