from langchain_google_genai import ChatGoogleGenerativeAI
from langchain_core.prompts import PromptTemplate
import time
from dotenv import load_dotenv
import requests
import os

load_dotenv()

GOOGLE_API_KEY = os.getenv("GOOGLE_API_KEY")

llm = ChatGoogleGenerativeAI(model="models/gemini-1.5-pro", google_api_key=GOOGLE_API_KEY)

# -------------------- 장소 추출 --------------------
def get_location_from_text(text: str) -> str:
    prompt = PromptTemplate.from_template(
    "다음 문장에서 장소명(예: 지역, 건물, 역 등)만 정확히 추출해줘. 설명하지 말고 장소명만 말해 .문장: {text}"
    )
    chain = prompt | llm
    result = chain.invoke({"text": text})
    return result.content.strip()
# -------------------- 위도/경도 변환 --------------------
def get_coordinates_from_location(location: str) -> str: 
    """
    장소명을 위도, 경도로 변환합니다. (예: 성신여자대학교 → 37.5928015,127.0166047)
    Google Maps Geocoding API 사용
    """
    url = "https://maps.googleapis.com/maps/api/geocode/json"
    params = {
        "address": location,
        "key": GOOGLE_API_KEY,
    }
   
    try:
        response = requests.get(url, params=params)
        data = response.json()

        if data.get("status") == "OK" and data.get("results"):
            location_data = data["results"][0].get("geometry", {}).get("location", {})
            lat = location_data.get("lat")
            lng = location_data.get("lng")
            if lat is not None and lng is not None:
                return {
                    "latitude": lat, "longitude": lng
                }
            else:
                return {"error": "위도 또는 경도 정보가 없습니다."}
        else:
            return {
                "error": f"API 실패: {data.get('status')}, {data.get('error_message', '원인 미상')}"
            }
    except Exception as e:
        return {"error": f"예외 발생: {str(e)}"}
    
    # -------------------- 음식점 검색 --------------------

def get_nearby_restaurants(latitude: float, longitude: float, radius: int = 1000) -> dict:
    url = "https://maps.googleapis.com/maps/api/place/nearbysearch/json"
    params = {
        "location": f"{latitude},{longitude}",
        "radius": radius,
        "type": "restaurant",
        "language": "ko",
        "key": GOOGLE_API_KEY
    }

    restaurants = []

    while True:
        try:
            response = requests.get(url, params=params)
            data = response.json()

            if data.get("status") != "OK":
                return {"error": f"API 실패: {data.get('status')}, {data.get('error_message', '원인 미상')}"}

            for place in data.get("results", []):
                rating = place.get("rating", 0)
                review_count = place.get("user_ratings_total", 0)
                restaurants.append({
                    "place_id": place.get("place_id"),
                    "name": place.get("name"),
                    "address": place.get("vicinity"),
                    "rating": rating,
                    "reviewCount": review_count,
                    "location": place.get("geometry", {}).get("location", {})
                })

            # 다음 페이지 토큰 확인
            next_page_token = data.get("next_page_token")
            if next_page_token:
                time.sleep(2)  # token 활성화까지 시간 필요
                params["pagetoken"] = next_page_token
            else:
                break  # 다음 페이지 없음 종료

        except Exception as e:
            return {"error": f"예외 발생: {str(e)}"}

    return {"restaurants": restaurants}


   # -------------------- 리뷰 검색 -------------------- 
def get_place_details(place_id: str) -> dict:
    url = "https://maps.googleapis.com/maps/api/place/details/json"
    params = {
        "place_id": place_id,
        "key": GOOGLE_API_KEY,
        "language": "ko",
        "fields": "name,review,rating,opening_hours"
    }

    try:
        response = requests.get(url, params=params)
        data = response.json()

        if data.get("status") != "OK":
            return {
                "error": f"API 오류: {data.get('status')}, {data.get('error_message', '원인 미상')}"
            }

        result = data.get("result", {})

        return {
            "name": result.get("name"),
            "opening_hours": result.get("opening_hours", {}).get("weekday_text"),
            "rating": result.get("rating"),
            "reviews": [
                {
                    "author": review.get("author_name"),
                    "rating": review.get("rating"),
                    "text": review.get("text")
                }
                for review in result.get("reviews", [])
            ]
        }

    except Exception as e:
        return {"error": f"예외 발생: {str(e)}"}
    
    

SPRING_SERVER = "http://localhost:8080"
JWT_TOKEN = os.getenv("JWT_TOKEN")
def get_nearby_restaurants_DB(latitude: float, longitude: float, radius: int = 500) -> dict:
    params = {
        "lat": latitude,
        "lng": longitude,
        "radius": radius
    }
    url = f"{SPRING_SERVER}/api/restaurants"
    headers = {"Authorization": f"Bearer {JWT_TOKEN}"}
    try:
        response = requests.get(url, headers=headers, params=params)
        if response.status_code == 200:
            data = response.json()
            return {"restaurants": data}  # 리스트면 감싸서 dict로
        else:
            return {"restaurants": None}
    except Exception as e:
        return {"error": f"예외 발생: {str(e)}"}
    


def findall_restaurants_DB() -> dict:
    url = f"{SPRING_SERVER}/api/restaurants/all"
    headers = {"Authorization": f"Bearer {JWT_TOKEN}"}
    try:
        response = requests.get(url, headers=headers)
        if response.status_code == 200:
            data = response.json()
            return {"restaurants": data}  # 리스트면 감싸서 dict로
        else:
            return {"restaurants": None}
    except Exception as e:
        return {"error": f"예외 발생: {str(e)}"}
    
    

