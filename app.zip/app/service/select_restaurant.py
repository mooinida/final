from langchain_google_genai import ChatGoogleGenerativeAI
from langchain_core.prompts import PromptTemplate

from dotenv import load_dotenv
import requests
import os
SPRING_SERVER = "http://localhost:8080"
JWT_TOKEN = os.getenv("JWT_TOKEN")
load_dotenv()

GOOGLE_API_KEY = os.getenv("GOOGLE_API_KEY")

llm = ChatGoogleGenerativeAI(model="models/gemini-1.5-pro", google_api_key=GOOGLE_API_KEY)


def extraction_keyword(text: str) -> str:
    prompt = PromptTemplate.from_template(
    "다음 문장에서 식당 관련 키워드를 추출하고, 각 키워드마다 유사어를 3개씩 추가해서 하나의 리스트로 만들어줘. "
    "형식은 쉼표로 구분된 키워드들의 나열이야. 예: 깔끔한, 청결한, 위생적인, 정돈된, ...\n"
    "문장: {text}"
    )
    chain = prompt | llm
    result = chain.invoke({"text": text})
    keywords= result.content.strip()
    return [kw.strip() for kw in keywords.split(",") if kw.strip()]


def compare_to_restaurantKeyword(keywords:list):
    url = f"{SPRING_SERVER}/api/keywords/recommend"
    headers = {"Authorization": f"Bearer {JWT_TOKEN}"}
    try:
        response = requests.post(url, headers=headers, json=keywords)
        response.raise_for_status()
        return response.json()
    except requests.RequestException as e:
        return [f"리뷰 텍스트 요청 실패: {e}"]
