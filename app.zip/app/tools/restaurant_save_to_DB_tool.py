import asyncio
from langchain_core.tools import tool
from send_to_server import send_restaurant, send_reviews, restaurant_is_exist
from service.keyword_extraction import process_and_store_keywords

from service.saveRestaurant_pipeline import (
    get_location_from_text,
    get_coordinates_from_location,
    get_nearby_restaurants,
    get_nearby_restaurants_DB,
    get_place_details,
)


@tool
async def process_and_store_restaurants(text: str):
    """
    사용자의 입력으로 지역을 추출하고 해당 지역의 식당과 리뷰를 db에 저장하는 역할.
    """
    location = get_location_from_text(text)
    print(f"📍 추출된 장소: {location}")

    coords = get_coordinates_from_location(location)
    if "error" in coords:
        return coords

    
    restaurants_data = get_nearby_restaurants_DB(coords["latitude"], coords["longitude"])

    # 1. 오류 먼저 확인
    if "error" in restaurants_data:
        return restaurants_data  # 진짜 오류니까 종료

    # 2. 결과가 없으면 fallback
    if not restaurants_data or len(restaurants_data) < 5:
        restaurants_data = get_nearby_restaurants(coords["latitude"], coords["longitude"])
        if "error" in restaurants_data:
            return restaurants_data

    async def process_one_restaurant(place, location):
        details = await asyncio.to_thread(get_place_details,place["place_id"])
        if "error" in details:
            print(f"❌ 상세정보 조회 실패: {place['name']} - {details['error']}")
            return
    
        opening_hours_raw = details.get("opening_hours")
        opening_hours = "\n".join(opening_hours_raw) if isinstance(opening_hours_raw, list) else opening_hours_raw
        restaurant_payload = {
            "placeId": place["place_id"],
            "name": place["name"],
            "address": place["address"],
            "rating": place["rating"],
            "latitude": place["location"]["lat"],
            "longitude": place["location"]["lng"],
            "reviewCount": place["reviewCount"],
            "openingHours": opening_hours,
            "location":location
        }
        if not restaurant_is_exist(place["place_id"]):
            await asyncio.to_thread(send_restaurant, restaurant_payload)
            print(f"✅ 식당 저장: {place['name']}")
            await asyncio.to_thread(send_reviews, place["place_id"], details.get("reviews", []))
            await asyncio.to_thread(process_and_store_keywords, place["place_id"], details)
            print(f"저장완료:{place['name']}")

    tasks = [process_one_restaurant(place, location) for place in restaurants_data["restaurants"]]
    await asyncio.gather(*tasks)

    return {"status": "done", "count": len(restaurants_data["restaurants"])}
    
        
    

