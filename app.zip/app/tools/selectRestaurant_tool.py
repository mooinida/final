from langchain_core.tools import tool
from service.select_restaurant import(
    extraction_keyword,
    compare_to_restaurantKeyword
)
import requests
import os
from dotenv import load_dotenv

load_dotenv()

SPRING_SERVER = "http://localhost:8080"
JWT_TOKEN = os.getenv("JWT_TOKEN")

@tool
def recommend_by_keywords(text:str)->dict:
    """
    사용자의 입력에서 키워드 및 관련어를 추출하고,
    식당 키워드와 비교하여 유사한 식당을 뽑습니다.
    """
    keywords = extraction_keyword(text)
    result =  compare_to_restaurantKeyword(keywords)
    return {"recommended_restaurants": result}

@tool
def explain_recommendation_reason(place_id: str) -> str:
    """
    식당을 추천한 이유을 설명합니다.
    """

@tool
def summarize_reviews(place_id: str) -> str:
    """
    리뷰를 요약하여 보여줍니다.
    """
    url = f"{SPRING_SERVER}/api/restaurants/summary/{place_id}"
    headers = {"Authorization": f"Bearer {JWT_TOKEN}"}
    response = requests.get(url, headers=headers)
    if response.status_code == 200:
        return response.text.strip()
    else:
        return f"❌ 요약 조회 실패 (status: {response.status_code})"


@tool
def get_detailed_info(place_id: str) -> dict:
    """
    식당의 상세정보를 보여줍니다.
    """