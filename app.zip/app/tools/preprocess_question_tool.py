from langchain_core.tools import tool
from langchain_google_genai import ChatGoogleGenerativeAI
from dotenv import load_dotenv
import os

# 환경변수 불러오기
load_dotenv()
GOOGLE_API_KEY = os.getenv("GOOGLE_API_KEY")

llm = ChatGoogleGenerativeAI(model="models/gemini-1.5-pro", google_api_key=GOOGLE_API_KEY)

@tool
def preprocess_question(user_input: str) -> str:
    """
    사용자의 질문을 LLM을 사용해 명확한 추천용 문장으로 재구성합니다.
    """
    prompt = f"""
    다음 문장을 벡터 검색에 적합하게 식당 추천 의도를 명확하고 구체적인 질문으로 다시 작성해줘:\n"{user_input}"
    예: "조용한 데 가고싶어" → "강남역 근처 조용한 분위기의 식당 추천해줘"
    예: "혼밥할 곳" → "강남역 근처 혼자 식사하기 좋은 식당 추천해줘"
    """
    try:
        response = llm.invoke(prompt)
        return response.content.strip()
    except Exception as e:
        return f"❌ 전처리 실패: {e}"
