from service.review_fetch import get_review_texts, merge_reviews_for_summary
from langchain_core.tools import tool
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain_core.prompts import PromptTemplate

from dotenv import load_dotenv
import os
load_dotenv()

GOOGLE_API_KEY = os.getenv("GOOGLE_API_KEY")

llm = ChatGoogleGenerativeAI(model="models/gemini-1.5-pro", google_api_key=GOOGLE_API_KEY)

@tool
def summarize_reason(place_id:str)->str:
    """
    특정 식당의 리뷰들을 요약하여 추천 사유를 한 문장으로 생성합니다.
    """
    reviews = get_review_texts(place_id)
    merge_reviews=merge_reviews_for_summary(reviews)
    if not merge_reviews.strip():
        return "리뷰 정보가 부족하여 추천 사유를 생성할 수 없습니다."
    prompt = PromptTemplate.from_template(
    "다음 리뷰들을 읽고 이 식당에 대하여 1~2줄로 요약해줘. "
    "긍정적인 부분 뿐만 아니라 부정적인 부분도 지적해주면 좋아. "
    "(예: 이 식당은 정말 맛있지만 비싸다는 평이 있음. "
    "직원이 친절하다는 평가가 있지만 위생이 안좋다는 평가도 있음.) "
    "다음은 리뷰입니다:\n{merge_reviews}"
    )
    chain = prompt | llm
    try:
        result = chain.invoke({"merge_reviews": merge_reviews})
        return result.content.strip()
    except Exception as e:
        print(f"요약 실패: {e}")
        return "요약 생성 중 오류가 발생했습니다."

